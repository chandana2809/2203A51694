const express = require("express");
const axios = require("axios");
const app = express();
const PORT = 3000;

let slidingWindow = [];

app.get("/numbers/avg", async (req, res) => {
    const urls = req.query.url;

    if (!urls) {
        return res.status(400).json({ error: "No URL provided" });
    }

    const urlList = Array.isArray(urls) ? urls : [urls];

    try {
        for (const url of urlList) {
            const response = await axios.get(url, { timeout: 500 });
            const numbers = response.data.numbers || [];

            for (const num of numbers) {
                if (!slidingWindow.includes(num)) {
                    slidingWindow.push(num);
                    if (slidingWindow.length > 10) {
                        slidingWindow.shift();
                    }
                }
            }
        }

        const average =
            slidingWindow.reduce((sum, num) => sum + num, 0) /
            slidingWindow.length;

        res.json({
            numbers: slidingWindow,
            average: average.toFixed(2),
        });
    } catch (err) {
        res.status(500).json({ error: "Error fetching or processing data." });
    }
});

app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
});
